package com.sj.di_demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DiDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DiDemoApplication.class, args);
	}

}
